﻿using RecruitingSample.Data;
using RecruitingSample.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace RecruitingSample.Controllers.Api
{
    public class CompaniesApiController : ApiController
    {
        private readonly CompaniesContext _companiesContext;

        public CompaniesApiController()
        {
            _companiesContext = new CompaniesContext();
            _companiesContext.Configuration.LazyLoadingEnabled = false;
        }

        [HttpGet]
        [Route("api/companies")]
        public IEnumerable<Company> GetAllCompanies()
        {
            return _companiesContext.Companies.OrderBy(c => c.Name);
        }


        [HttpGet]
        [Route("api/employees/{companyId}")]
        public IEnumerable<Employee> GetEmployeesByCompanyId(int companyId)
        {
            return _companiesContext.Employees.Where(e => e.CompanyID == companyId);
        }
    }
}