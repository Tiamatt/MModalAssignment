﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RecruitingSample.Models
{
    public class Employee
    {
        public int ID { get; set; }
        public int CompanyID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public virtual Company Company { get; set; }
    }
}