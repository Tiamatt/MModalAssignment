﻿import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Route, Switch, Link } from 'react-router-dom';
import { Employees } from "./employees";
import { Companies } from "./companies";

export class Content extends React.Component {

    constructor() {
        super();
    }

    render() {
        return (
            <div>
                <BrowserRouter>
                    <Switch>
                        <Route path="/" exact component={Companies} /> 
                        <Route path="/employees/:companyId" exact component={Employees} />
                        <Route path="*" component={Companies} /> 
                    </Switch>
                </BrowserRouter>
            </div>
        );
    }
}