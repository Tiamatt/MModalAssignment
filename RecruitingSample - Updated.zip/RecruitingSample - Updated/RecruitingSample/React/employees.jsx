﻿import React from 'react';
import ReactDOM from 'react-dom';
import axios from "axios";
import {Link} from 'react-router-dom';

export class Employees extends React.Component {

    constructor() {
        super();
        this.state = {
            employees: []
        };
    }

    componentDidMount() {
        let companyId = this.props.match.params.companyId;
        if (companyId) {
            axios.get('/api/employees/' + companyId)
                .then(response => {
                   let apiEmployees = response.data.sort((prev, next) => {
                           let fullNamePrev = (prev.LastName + ' ' + prev.FirstName).toLowerCase();
                           let fullNameNext = (next.LastName + ' ' + next.FirstName).toLowerCase();
                       return (fullNamePrev < fullNameNext) ? -1 : 1;
                    });

                    this.setState({
                        employees: apiEmployees,
                    });
                })
                .catch(error => {
                    console.log('Get employees error: ', error);
                });
        }
    }

    render() {
        const employeeRows = (this.state.employees.length > 0)
            ? this.state.employees.map((employee) => (
                <tr scope="row" key={employee.ID}>
                    <td>{employee.LastName + ', ' + employee.FirstName}</td>
                </tr>))
            : <tr><td>No results</td></tr>;
        return (
            <div>
                <h2>Employees</h2>
                <table className="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Employee Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        {employeeRows}
                    </tbody>
                </table>
                <Link to="/">Back</Link>
            </div>
        );
    }
}