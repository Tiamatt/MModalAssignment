﻿import React from 'react';
import ReactDOM from 'react-dom';
import axios from "axios";
import { Link } from 'react-router-dom';

export class Companies extends React.Component {

    constructor() {
        super();
        this.state = {
            initialCompanies: [],
            companies: [],
        };
    }

    componentWillMount() {
        axios.get('/api/companies')
            .then(response => {
                this.setState({
                    initialCompanies: response.data,
                    companies: response.data,
                });
            })
            .catch(error => {
                console.log('Get companies error: ', error);
            });
    }

    onSearchEmployee = (event) => {
        let updatedCompanies = this.state.initialCompanies;

        updatedCompanies = updatedCompanies.filter(company => {
            return company.Name.toLowerCase().search(event.target.value.toLowerCase())  !== -1;
        });

        this.setState({
            companies: updatedCompanies,
        });
    } 

    render() {
        const companyRows = this.state.companies.map((company) => (
            <tr scope="row" key={company.ID}>
                <td>
                    <Link to={"/employees/" + company.ID}>{company.Name}</Link>
                </td>
            </tr>
        ));

        const form = (
            <form>
                <fieldset className="form-group">
                    <input type="text" className="form-control form-control-lg" placeholder="Start typing name" onChange={this.onSearchEmployee} />
                </fieldset>
            </form>
            );
        return (
            <div>
                <h2>Companies</h2>
                {form}    
                <table className="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Company Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        {companyRows}
                    </tbody>
                </table>
            </div>
        );
    }
}