﻿import * as React from 'react';
import * as ReactDOM from 'react-dom';
import { Content } from "./content";

ReactDOM.render(<Content/>, document.getElementById("app") );