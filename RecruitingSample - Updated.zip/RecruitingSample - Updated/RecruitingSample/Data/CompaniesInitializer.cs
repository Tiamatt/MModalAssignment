﻿using RecruitingSample.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RecruitingSample.Data
{
    public class CompaniesInitializer : System.Data.Entity.DropCreateDatabaseIfModelChanges<CompaniesContext>
    {
        protected override void Seed(CompaniesContext context)
        {
            var companies = new List<Company>
            {
                new Company{ID=1, Name="Nike"},
                new Company{ID=2, Name="Adidas"},
                new Company{ID=3, Name="Puma"},
                new Company{ID=4, Name="New Balance"}
            };
            companies.ForEach(c => context.Companies.Add(c));
            context.SaveChanges();

            var employees = new List<Employee>
            {
                new Employee{ID=1, CompanyID=1, FirstName="Jane", LastName="Green"},
                new Employee{ID=1, CompanyID=1, FirstName="Joe", LastName="White"},
                new Employee{ID=1, CompanyID=1, FirstName="Frank", LastName="Mustard"},
                new Employee{ID=1, CompanyID=2, FirstName="Sam", LastName="Plum"},
                new Employee{ID=1, CompanyID=2, FirstName="Michael", LastName="Rouge"},
                new Employee{ID=1, CompanyID=2, FirstName="John", LastName="Violet"},
                new Employee{ID=1, CompanyID=3, FirstName="Jennifer", LastName="Silver"},
                new Employee{ID=1, CompanyID=3, FirstName="Jessica", LastName="Gold"},
            };
            employees.ForEach(e => context.Employees.Add(e));
            context.SaveChanges();
        }
    }
}