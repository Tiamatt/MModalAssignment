﻿"use strict";

var glob = require("glob");

module.exports = {
    entry:
        {
            "app": glob.sync('./React/*.*'),
        },

    output: {
        filename: "./obj/webpack/[name].bundle.js"
    },
    module: {
        rules: [
            {
                test: [/.(ttf|otf|eot|svg|woff(2)?)(\?[a-z0-9]+)?$/],
                use: [{
                    loader: 'file-loader',
                    options: {
                        name: '[name].[ext]',
                        outputPath: 'obj/webpack/fonts/',    // where the fonts will go
                        publicPath: '../'       // override the default path
                    }
                }]
            },
            {
                test: [/\.css$/],
                loaders: ['style-loader', 'css-loader'],
                //exclude: /node_modules/
            },
            {
                test: [/\.tsx?$/, /\.ts$/],
                loaders: ["babel-loader", "awesome-typescript-loader"],
                exclude: /node_modules/
            },
            {
                test: [/\.js$/, /\.jsx$/],
                loader: "babel-loader",
                exclude: /node_modules/,
                query: {
                    presets: ["es2015", "react"],
                    plugins: ["transform-decorators-legacy", "transform-class-properties"]
                }
            }
        ]
    },
    resolve: {
        extensions: ['.ts', '.tsx', '.js', '.jsx'],
        modules: ['./React', 'node_modules']
    },

};